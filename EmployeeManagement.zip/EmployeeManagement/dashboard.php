<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'database.php';

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$sql = "SELECT * FROM adminusers";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Employee Management | Home</title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>

</head>
<body>

<fieldset>
<fieldset>

    <header>
    <h1>Employee Management</h1>

    <nav>
    
    <a href=>Logged in as <?php echo $_SESSION['username']; ?></a>
    
    <a href="logout.php">| Logout</a>
    </nav>
    </header>

    



    <ul>
        <li><a href="registerNewEmployer.php">Register New Employer</a></li>
        <li><a href="updateEmployerInfo.php">Update Employer Information</a></li>
        <li><a href="deleteEmployerInfo.php">Delete Employer Information</a></li>
        <li><a href="searchEmployerInfo.php">Search Employer Information</a></li>
        
        
    </ul>

</fieldset>
</fieldset>

</body>
</html>



