<?php
session_start();



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'database.php';

    $username = $_POST['username'];
    $name = $_POST['name'];
    $company = $_POST['company'];
    $contact = $_POST['contact'];
    
    

    $checkUsername = "SELECT * FROM employee_info WHERE username='$username'";
    $result = mysqli_query($conn, $checkUsername);

    if (mysqli_num_rows($result) > 0) {
        $error = "Username already exists";
    } else {
        $insertUser = "INSERT INTO employee_info (username, name, company, contact) VALUES ('$username', '$name', '$company' , '$contact')";

        if (mysqli_query($conn, $insertUser)) {
            
            // echo "New Employee Registered";
            header('Location: dashboard.php');
           
            exit;
        } else {
            $error = "Error creating user: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Register New Employee</title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>

</head>
<body>

<fieldset>
<fieldset>

<header>
<h1>Employe Management</h1>

<nav>
    
    <a href=>Logged in as <?php echo $_SESSION['username']; ?></a>
    <a href="logout.php">| Logout</a>

</nav>
</header>

    <h1>Register New Employee</h1>
    <?php if (isset($error)): ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="post">

    <div>

        <label for="name">Name :</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="username">Username :</label>
        <input type="text" name="username" required><br><br>

        <label for="company">Company Name :</label>
        <input type="text" id="company" name="company" required><br><br>

        <label for="contact">Contact Number :</label>
        <input type="text" name="contact" required><br><br>

        <br><br><input type="submit" value="Regiser">
        <input type="reset" name="reset" value="reset"><br><br>
        
    </div>
    </form>

</fieldset>
</fieldset>

        <br><a href="dashboard.php">Back</a><br>

</body>
</html>