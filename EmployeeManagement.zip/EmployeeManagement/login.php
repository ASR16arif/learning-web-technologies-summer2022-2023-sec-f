<?php
session_start();

if (isset($_SESSION['username'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'database.php';

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM adminusers WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION['username'] = $username;
        header('Location: dashboard.php');
        exit;
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Employee Management | Login</title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>

</head>
<body>

<fieldset>
<fieldset>
    
<header>
<h1>Employee Management</h1>

<nav>
<a href="index.php">Home</a>
<a href="login.php">| Login</a>
<a href="signup.php">| Signup</a>
</nav>
</header>

    <h1>Login</h1>
    <?php if (isset($error)): ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="post">
            Username:   <input type="text" name="username" value="" /><br><br>
            Password:   <input type="password" name="password" value="" /> <br><br>

        <input type="submit" value="Login">
    </form>

</fieldset>
</fieldset>

</body>
</html>