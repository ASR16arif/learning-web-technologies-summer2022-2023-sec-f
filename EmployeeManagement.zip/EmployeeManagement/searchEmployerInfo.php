<?php
session_start();
require_once 'database.php';

// Search employee by username
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $search_username = $_POST['search_username'];

    $sql = "SELECT * FROM employee_info WHERE username = '$search_username'";
    $result = mysqli_query($conn, $sql);
    $employee = mysqli_fetch_assoc($result);
}

?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Search Employee</title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>

</head>
<body>

<fieldset>
<fieldset>

<header>
<h1>Employe Management</h1>

<nav>
    
    <a href=>Logged in as <?php echo $_SESSION['username']; ?></a>
    <a href="logout.php">| Logout</a>

</nav>
</header>

        <!-- Search form -->
        <h2>Search Employee</h2>
        <form method="post">
            <label for="search_username">Search by Username:</label>
            <input type="text" id="search_username" name="search_username" required>
            <input type="submit" name="search" value="Search">
        </form>

        <!-- Display search result if available -->
        <?php if (isset($employee)): ?>
            <h3>Search Result:</h3>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <p>Name: <?php echo $employee['name']; ?></p>
                <p>Username: <?php echo $employee['username']; ?></p>
                <p>Company: <?php echo $employee['company']; ?></p>
                <p>Contact: <?php echo $employee['contact']; ?></p>
            <?php else: ?>
                <p>No employee found with the given username.</p>
            <?php endif; ?>
        <?php endif; ?>

</fieldset>
</fieldset>

        <br><a href="dashboard.php">Back</a><br>

</body>
</html>