<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $option = $_POST['option'];

    if ($option === 'login') {
        header('Location: login.php');
        exit;
    } elseif ($option === 'signup') {
        header('Location: signup.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Web Page | Employee Management</title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>
    
</head>
<body>

<fieldset>
<fieldset>

<header>
<h1>Employee Management</h1>

<nav>
<a href="index.php">Home</a>
<a href="login.php">| Login</a>
<a href="signup.php">| Signup</a>
</nav>
</header>

    <h1>Welcome to the Home Page!</h1>
    <p>Please Login or Signup to access this website!</p>

</fieldset>
</fieldset>
    
</body>
</html>