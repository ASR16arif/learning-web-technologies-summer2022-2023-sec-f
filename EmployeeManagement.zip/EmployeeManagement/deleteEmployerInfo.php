<?php
session_start();
require_once 'database.php';

// Search employee by username
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $search_username = $_POST['search_username'];

    $sql = "SELECT * FROM employee_info WHERE username = '$search_username'";
    $result = mysqli_query($conn, $sql);
    $employee = mysqli_fetch_assoc($result);
    
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    $username = $_POST['username'];

    $deleteUser = "DELETE FROM employee_info WHERE username = '$username'";

    if (mysqli_query($conn, $deleteUser)) {
        $success_message = "Employee deleted successfully!";
        $employee = null;

        header('Location: dashboard.php');        
    } else {
        $error = "Error deleting employee: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Delete Employee</title>

<style>
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;

    }
    header h1 {
        margin: 0;
        font-size: 24px;
    }
    header a {

        text-decoration: none;
        margin-left: 10px;
        font-size: 16px;
    }
</style>

</head>
<body>

<fieldset>
<fieldset>

<header>
<h1>Employe Management</h1>

<nav>
    
    <a href=>Logged in as <?php echo $_SESSION['username']; ?></a>
    <a href="logout.php">| Logout</a>

</nav>
</header>

        <!-- Search form -->
        <h2>Search Employee</h2>
        <form method="post">
            <label for="search_username">Search by Username:</label>
            <input type="text" id="search_username" name="search_username" required>
            <input type="submit" name="search" value="Search">
        </form>

        <form method="post">
                    <input type="hidden" name="username" value="<?php echo $employee['username']; ?>">
                    <label for="new_username">New Username:</label>
                    <input type="text" id="new_username" name="new_username" value="<?php echo $employee['username']; ?>" required><br><br>

                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo $employee['name']; ?>" required><br><br>

                    <label for="company">Company Name:</label>
                    <input type="text" id="company" name="company" value="<?php echo $employee['company']; ?>" required><br><br>

                    <label for="contact">Contact Number:</label>
                    <input type="text" name="contact" value="<?php echo $employee['contact']; ?>" required><br><br>


                    <input type="submit" name="delete" value="Delete" onclick="return confirm('Are you sure you want to delete this employee?');">
                </form>
            





</fieldset>
</fieldset>

        <br><a href="dashboard.php">Back</a><br>

</body>
</html>