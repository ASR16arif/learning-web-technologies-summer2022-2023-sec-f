<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

require_once 'database.php';



$username = $_SESSION['username'];
$sql = "SELECT * FROM users WHERE username='$username'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = $_POST['username'];
    $newPassword = $_POST['password'];

    $updateSql = "UPDATE users SET username='$newUsername', password='$newPassword' WHERE username='$username'";

    if (mysqli_query($conn, $updateSql)) {
        $_SESSION['username'] = $newUsername;
        header('Location: view_profile.php');
        exit;
    } else {
        $error = "Error updating profile: " . mysqli_error($conn);
    }
}

mysqli_close($conn);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
</head>
<body>
 

    <h1>Edit Profile</h1>
    <?php if (isset($error)): ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" value="<?php echo $row['username']; ?>" required>

        <label for="password">Password:</label>
        <input type="password" name="password" value="<?php echo $row['password']; ?>" required>

        <input type="submit" value="Save Changes">

        <br><a href="dashboard.php">Back</a>
    </form>



</body>
</html>