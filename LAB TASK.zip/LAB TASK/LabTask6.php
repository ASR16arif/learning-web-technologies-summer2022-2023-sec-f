<?php

$my_array = array(10, 20, 30, 40, 50);


$element = 30;


for ($i = 0; $i < count($my_array); $i++) {
   if ($my_array[$i] == $element) {
       echo "Element found at index " . $i;
       break;
   }
}


if ($i == count($my_array)) {
   echo "Element not found in the array";
}
?>