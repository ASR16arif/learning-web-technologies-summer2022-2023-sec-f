<?php

$amount = 100;
$vat_rate = 0.15;


$vat = $amount * $vat_rate;

$total = $amount + $vat;


echo "<h2>Results:</h2>";
echo "Amount: $" . $amount . "<br>";
echo "VAT (" . ($vat_rate * 100) . "%): $" . $vat . "<br>";
echo "Total (including VAT): $" . $total;
?>