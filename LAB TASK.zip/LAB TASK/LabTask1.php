<?php

$length = 5;
$width = 2;


$area = $length * $width;
$perimeter = 2 * ($length + $width);


echo "<h2>Results:</h2>";
echo "The area of Rectangle: " . $area . "<br>";
echo "Perimeter: " . $perimeter;
?>