<?php
// Loop through all numbers between 10 and 100
for ($i = 10; $i <= 100; $i++) {
   // Check if the number is odd
   if ($i % 2 != 0) {
       echo $i . " ";
   }
}
?>